class DictAsObj(object):
    def __init__(self, d):
        self.__dict__ = d
