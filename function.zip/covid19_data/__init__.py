from covid19_data.JHU import dataByCallerName, dataByCallerNameShort, dataByName, dataByNameShort, jsonByCallerName, \
    jsonByCallerNameShort, jsonByName, jsonByNameShort
from covid19_data import JHU
